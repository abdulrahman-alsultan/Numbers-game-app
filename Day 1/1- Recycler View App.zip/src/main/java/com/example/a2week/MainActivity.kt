package com.example.a2week

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val names = ArrayList<String>()
        val myRV = findViewById<RecyclerView>(R.id.rvMain)

        val button = findViewById<Button>(R.id.addButton)
        val name = findViewById<EditText>(R.id.friendsName)
        button.setOnClickListener{
            val n = name.text.toString()
            if(n.isNotEmpty()){
                names.add(n)
                myRV.adapter = RecyclerViewAdapter(names)
                myRV.layoutManager = LinearLayoutManager(this)
            }
        }
    }
}